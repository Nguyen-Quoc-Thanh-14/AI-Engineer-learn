# Chương F01

> Bản đọc gộp v2.5, sinh trực tiếp từ file bài học.

## Nội dung các bài học — đồng bộ v2.5


---

# F01.01 — Module, import và namespace

> **Trạng thái:** ĐÃ BIÊN SOẠN BẢN THẢO CHUYÊN BIỆT; VÍ DỤ VÀ LỜI GIẢI CHẠY ĐẠT PYTHON 3.13.5.
> **Giai đoạn:** GD2 · **Chương:** F01 — Module và import · **Đích:** CPython 3.15.2.

## 1. Chuẩn đầu ra có thể kiểm chứng

1. Tự giải thích khái niệm **Module, import và namespace**, nêu một trường hợp nên và không nên áp dụng.
2. Dự đoán trạng thái/kết quả ví dụ trước khi chạy và giải thích từng bước.
3. Viết một lời giải độc lập, xử lý ít nhất ba trường hợp (bình thường, biên, sai đầu vào).
4. Chỉ ra giả định, giới hạn và đối chiếu kết quả bằng kiểm thử.

**Tiên quyết:** B, O01.

## 2. Khái niệm — Bản chất

Mỗi module thường có namespace riêng, được nhập qua `import`. Code ở module-level có thể được thực thi trong lần import đầu tiên ở interpreter hiện tại và module được cache trong `sys.modules`.

## 3. Nguyên lý và cơ chế từng bước

Xác định đầu vào và hợp đồng → thực hiện bước biến đổi → kiểm tra kết quả bằng `assert` → thử thêm ca biên; giải thích từng dòng thay vì chỉ nhìn đầu ra.

## 4. Ví dụ tối thiểu có thể chạy

```python
import math
assert math.isqrt(16)==4
assert 'math' in __import__('sys').modules
print(math.pi > 3)
```

**Kết quả kiểm thử cục bộ:** pass trên Python 3.13.5.

```text
True
```

**Thực hành:** chạy file `07_MA_VI_DU/F01.01_vi_du.py` từ thư mục gốc giáo trình rồi sửa một tham số để dự đoán sự khác biệt.

## 5. Trường hợp biên, lỗi thường gặp và hướng debug

- **Ngộ nhận:** Không đặt file của mình là `json.py`, `math.py`, `typing.py` vì có thể shadow standard library.
- **Trường hợp biên:** Module import lỗi ở top-level có thể khiến cả lệnh import thất bại.
- **Debug có phương pháp:** xác định hợp đồng → tái hiện lỗi bằng đầu vào tối thiểu → đọc traceback/kiểm tra trạng thái → sửa → thêm regression test.

## 6. So sánh lựa chọn kỹ thuật và đánh đổi

So sánh với cách xử lý không có cấu trúc trước khi thêm abstraction.

## 7. Bài tập có yêu cầu kiểm chứng

Dùng import `statistics` và viết hàm tính mean khi list không rỗng.

**Bài tập độc lập:** bổ sung ca thử bình thường, biên, sai dữ liệu; giải thích đầu ra và một cách triển khai khác. Không xem lời giải mẫu trước khi tự viết.

**Lời giải:** [F01.01_loi_giai.md](LOI_GIAI/F01.01_loi_giai.md).

## 8. Câu hỏi kiểu mentor để tự đánh giá

1. Nếu chỉ được giải thích nguyên lý bằng ba câu, bạn sẽ giữ lại những điều kiện nào và vì sao?
2. Nếu thay đổi dữ liệu đầu vào thành rỗng, trùng, âm hoặc sai kiểu, quy tắc nào có thể thất bại?
3. Bạn sẽ dùng thử nghiệm nào để phản chứng lời giải hiện tại?
4. Trong trường hợp thực tế nào **Module, import và namespace** mang lại lợi ích lớn hơn độ phức tạp bổ sung?

## 9. Tiêu chí đạt và tự chấm

- [ ] Nói được khái niệm và cơ chế mà không nhìn đáp án.
- [ ] Chạy thành công ví dụ và ghi phiên bản runtime.
- [ ] Viết lời giải riêng, có ít nhất ba ca kiểm thử.
- [ ] Nhận diện và giải thích một cách làm sai hoặc giả định không hợp lệ.
- [ ] Nêu được tình huống lựa chọn phương pháp thay thế.

## 10. Nguồn và giới hạn

- [R03] [Python Language Reference 3.15](https://docs.python.org/3.15/reference/) — Chuẩn ngôn ngữ.
- [R07] [What’s New in Python 3.15](https://docs.python.org/3.15/whatsnew/3.15.html) — Chính thức.
- [R08] [PEP 810 Explicit Lazy Imports](https://peps.python.org/pep-0810/) — Chuẩn/PEP.
- [R11] [Python Packaging User Guide](https://packaging.python.org/en/latest/) — Gốc.
- [R20] [uv Documentation](https://docs.astral.sh/uv/) — Chính thức thư viện.

Giải thích và bài tập được biên soạn mới để học tập; dùng các nguồn nêu trên để đối chiếu, không sao chép nguyên văn sách.
**Chưa kiểm chứng:** tính tương thích trực tiếp với CPython 3.15.2; kiểm định sư phạm độc lập; độ tương thích các bộ thư viện trên máy người học.

---

## 11. Bài chuyên sâu bổ sung v2.5 — kiểm định bằng chương trình thực thi

> **Kết quả:** Đã chạy thành công lời giải độc lập trên Python 3.13.5 tại thời điểm xuất bản v2.5. **Chưa kiểm định trực tiếp trên CPython 3.15.2; chưa qua phản biện sư phạm độc lập.**

### Nguyên lý cần nắm

Mỗi module là một namespace; import gắn đối tượng module hoặc một tên tham chiếu vào namespace hiện tại. sys.modules lưu cache các module đã nạp.

### Cách suy luận và thiết kế lời giải

Phân biệt `import math` với `from math import sqrt`: cách đầu gắn tên math; cách sau gắn tên sqrt tại module gọi. importlib.import_module giúp import động theo chuỗi, nhưng chỉ nên nhận tên module đã allowlist nếu đầu vào có thể do người dùng kiểm soát.

### Phản ví dụ và ngộ nhận cần tránh

Không cho rằng `from m import name` tạo một liên kết động luôn theo sát việc gán lại m.name. Nó chỉ lấy tham chiếu vào đối tượng tại thời điểm import.

### Lộ trình tự kiểm tra

1. Đọc yêu cầu bài tập ở trên, tự viết lời giải **trước khi mở đáp án**.
2. Dự đoán đầu ra các trường hợp bình thường, biên và không hợp lệ; nói rõ từng precondition, hậu điều kiện.
3. Chạy mã độc lập [`F01.01_bai_tap_da_giai_v25.py`](MA_MAU/F01.01_bai_tap_da_giai_v25.py) để đối chiếu.
4. Kiểm tra lời giải chi tiết: [`F01.01_loi_giai.md`](LOI_GIAI/F01.01_loi_giai.md).
5. **Bài mở rộng:** Tạo module `config.py` với một hằng số, nhập nó từ file main và chỉ ra khác biệt giữa import cache và reload.

**Nguồn kỹ thuật chính thức:** https://docs.python.org/3.15/reference/import.html. Tài liệu được dùng để đối chiếu API/cơ chế, không phải nguồn sao chép nguyên văn bài này.


---

# F01.02 — Package, __init__.py, __name__ và __main__

> **Trạng thái:** ĐÃ BIÊN SOẠN BẢN THẢO CHUYÊN BIỆT; VÍ DỤ VÀ LỜI GIẢI CHẠY ĐẠT PYTHON 3.13.5.
> **Giai đoạn:** GD2 · **Chương:** F01 — Module và import · **Đích:** CPython 3.15.2.

## 1. Chuẩn đầu ra có thể kiểm chứng

1. Tự giải thích khái niệm **Package, __init__.py, __name__ và __main__**, nêu một trường hợp nên và không nên áp dụng.
2. Dự đoán trạng thái/kết quả ví dụ trước khi chạy và giải thích từng bước.
3. Viết một lời giải độc lập, xử lý ít nhất ba trường hợp (bình thường, biên, sai đầu vào).
4. Chỉ ra giả định, giới hạn và đối chiếu kết quả bằng kiểm thử.

**Tiên quyết:** B, O01.

## 2. Khái niệm — Bản chất

Package nhóm module theo namespace. `__name__` cho biết tên module khi chạy; khi file được thực thi trực tiếp, `__name__` thường bằng `__main__`, cho phép đặt entry point mà không chạy khi import.

## 3. Nguyên lý và cơ chế từng bước

Xác định đầu vào và hợp đồng → thực hiện bước biến đổi → kiểm tra kết quả bằng `assert` → thử thêm ca biên; giải thích từng dòng thay vì chỉ nhìn đầu ra.

## 4. Ví dụ tối thiểu có thể chạy

```python
def main():
    return 'hello'

if __name__ == '__main__':
    print(main())
assert main()=='hello'
```

**Kết quả kiểm thử cục bộ:** pass trên Python 3.13.5.

```text
hello
```

**Thực hành:** chạy file `07_MA_VI_DU/F01.02_vi_du.py` từ thư mục gốc giáo trình rồi sửa một tham số để dự đoán sự khác biệt.

## 5. Trường hợp biên, lỗi thường gặp và hướng debug

- **Ngộ nhận:** `python file.py` và `python -m pkg.module` khác về module search path và package context.
- **Trường hợp biên:** Relative import cần package context phù hợp.
- **Debug có phương pháp:** xác định hợp đồng → tái hiện lỗi bằng đầu vào tối thiểu → đọc traceback/kiểm tra trạng thái → sửa → thêm regression test.

## 6. So sánh lựa chọn kỹ thuật và đánh đổi

So sánh với cách xử lý không có cấu trúc trước khi thêm abstraction.

## 7. Bài tập có yêu cầu kiểm chứng

Tạo module có `main()` và guard, nêu lệnh `python -m package.module` khi package có mặt trên import path.

**Bài tập độc lập:** bổ sung ca thử bình thường, biên, sai dữ liệu; giải thích đầu ra và một cách triển khai khác. Không xem lời giải mẫu trước khi tự viết.

**Lời giải:** [F01.02_loi_giai.md](LOI_GIAI/F01.02_loi_giai.md).

## 8. Câu hỏi kiểu mentor để tự đánh giá

1. Nếu chỉ được giải thích nguyên lý bằng ba câu, bạn sẽ giữ lại những điều kiện nào và vì sao?
2. Nếu thay đổi dữ liệu đầu vào thành rỗng, trùng, âm hoặc sai kiểu, quy tắc nào có thể thất bại?
3. Bạn sẽ dùng thử nghiệm nào để phản chứng lời giải hiện tại?
4. Trong trường hợp thực tế nào **Package, __init__.py, __name__ và __main__** mang lại lợi ích lớn hơn độ phức tạp bổ sung?

## 9. Tiêu chí đạt và tự chấm

- [ ] Nói được khái niệm và cơ chế mà không nhìn đáp án.
- [ ] Chạy thành công ví dụ và ghi phiên bản runtime.
- [ ] Viết lời giải riêng, có ít nhất ba ca kiểm thử.
- [ ] Nhận diện và giải thích một cách làm sai hoặc giả định không hợp lệ.
- [ ] Nêu được tình huống lựa chọn phương pháp thay thế.

## 10. Nguồn và giới hạn

- [R03] [Python Language Reference 3.15](https://docs.python.org/3.15/reference/) — Chuẩn ngôn ngữ.
- [R07] [What’s New in Python 3.15](https://docs.python.org/3.15/whatsnew/3.15.html) — Chính thức.
- [R08] [PEP 810 Explicit Lazy Imports](https://peps.python.org/pep-0810/) — Chuẩn/PEP.
- [R11] [Python Packaging User Guide](https://packaging.python.org/en/latest/) — Gốc.
- [R20] [uv Documentation](https://docs.astral.sh/uv/) — Chính thức thư viện.

Giải thích và bài tập được biên soạn mới để học tập; dùng các nguồn nêu trên để đối chiếu, không sao chép nguyên văn sách.
**Chưa kiểm chứng:** tính tương thích trực tiếp với CPython 3.15.2; kiểm định sư phạm độc lập; độ tương thích các bộ thư viện trên máy người học.


---

# F01.03 — sys.path và lỗi import phổ biến

> **Trạng thái:** ĐÃ BIÊN SOẠN BẢN THẢO CHUYÊN BIỆT; VÍ DỤ VÀ LỜI GIẢI CHẠY ĐẠT PYTHON 3.13.5.
> **Giai đoạn:** GD2 · **Chương:** F01 — Module và import · **Đích:** CPython 3.15.2.

## 1. Chuẩn đầu ra có thể kiểm chứng

1. Tự giải thích khái niệm **sys.path và lỗi import phổ biến**, nêu một trường hợp nên và không nên áp dụng.
2. Dự đoán trạng thái/kết quả ví dụ trước khi chạy và giải thích từng bước.
3. Viết một lời giải độc lập, xử lý ít nhất ba trường hợp (bình thường, biên, sai đầu vào).
4. Chỉ ra giả định, giới hạn và đối chiếu kết quả bằng kiểm thử.

**Tiên quyết:** B, O01.

## 2. Khái niệm — Bản chất

Khi import, Python tra cứu import path theo cấu hình và import system; `sys.path` là một đầu vào quan trọng nhưng không phải toàn bộ cơ chế. Tránh sửa sys.path tùy tiện trong mã ứng dụng.

## 3. Nguyên lý và cơ chế từng bước

Xác định đầu vào và hợp đồng → thực hiện bước biến đổi → kiểm tra kết quả bằng `assert` → thử thêm ca biên; giải thích từng dòng thay vì chỉ nhìn đầu ra.

## 4. Ví dụ tối thiểu có thể chạy

```python
import sys
assert isinstance(sys.path,list)
print('Độ dài import path:',len(sys.path)>0)
```

**Kết quả kiểm thử cục bộ:** pass trên Python 3.13.5.

```text
Độ dài import path: True
```

**Thực hành:** chạy file `07_MA_VI_DU/F01.03_vi_du.py` từ thư mục gốc giáo trình rồi sửa một tham số để dự đoán sự khác biệt.

## 5. Trường hợp biên, lỗi thường gặp và hướng debug

- **Ngộ nhận:** Module local trùng tên package được cài làm import trỏ sai nơi.
- **Trường hợp biên:** Chạy từ working directory khác nhau có thể phơi bày lỗi đóng gói dự án.
- **Debug có phương pháp:** xác định hợp đồng → tái hiện lỗi bằng đầu vào tối thiểu → đọc traceback/kiểm tra trạng thái → sửa → thêm regression test.

## 6. So sánh lựa chọn kỹ thuật và đánh đổi

So sánh với cách xử lý không có cấu trúc trước khi thêm abstraction.

## 7. Bài tập có yêu cầu kiểm chứng

Phác thảo cấu trúc src layout để import `myapp.service` từ môi trường đã cài editable.

**Bài tập độc lập:** bổ sung ca thử bình thường, biên, sai dữ liệu; giải thích đầu ra và một cách triển khai khác. Không xem lời giải mẫu trước khi tự viết.

**Lời giải:** [F01.03_loi_giai.md](LOI_GIAI/F01.03_loi_giai.md).

## 8. Câu hỏi kiểu mentor để tự đánh giá

1. Nếu chỉ được giải thích nguyên lý bằng ba câu, bạn sẽ giữ lại những điều kiện nào và vì sao?
2. Nếu thay đổi dữ liệu đầu vào thành rỗng, trùng, âm hoặc sai kiểu, quy tắc nào có thể thất bại?
3. Bạn sẽ dùng thử nghiệm nào để phản chứng lời giải hiện tại?
4. Trong trường hợp thực tế nào **sys.path và lỗi import phổ biến** mang lại lợi ích lớn hơn độ phức tạp bổ sung?

## 9. Tiêu chí đạt và tự chấm

- [ ] Nói được khái niệm và cơ chế mà không nhìn đáp án.
- [ ] Chạy thành công ví dụ và ghi phiên bản runtime.
- [ ] Viết lời giải riêng, có ít nhất ba ca kiểm thử.
- [ ] Nhận diện và giải thích một cách làm sai hoặc giả định không hợp lệ.
- [ ] Nêu được tình huống lựa chọn phương pháp thay thế.

## 10. Nguồn và giới hạn

- [R03] [Python Language Reference 3.15](https://docs.python.org/3.15/reference/) — Chuẩn ngôn ngữ.
- [R07] [What’s New in Python 3.15](https://docs.python.org/3.15/whatsnew/3.15.html) — Chính thức.
- [R08] [PEP 810 Explicit Lazy Imports](https://peps.python.org/pep-0810/) — Chuẩn/PEP.
- [R11] [Python Packaging User Guide](https://packaging.python.org/en/latest/) — Gốc.
- [R20] [uv Documentation](https://docs.astral.sh/uv/) — Chính thức thư viện.

Giải thích và bài tập được biên soạn mới để học tập; dùng các nguồn nêu trên để đối chiếu, không sao chép nguyên văn sách.
**Chưa kiểm chứng:** tính tương thích trực tiếp với CPython 3.15.2; kiểm định sư phạm độc lập; độ tương thích các bộ thư viện trên máy người học.


## Cập nhật chất lượng v2.7

Đã cập nhật file bài lẻ: F01.01, F01.02, F01.03. Ưu tiên đọc file bài lẻ để xem lời giải và demo mới, báo cáo kiểm thử tại thư mục `30_KIEM_DINH_V27`. Các bài chưa được kiểm thử trên Python 3.15.2 vẫn giữ trạng thái cần xác minh.
